package konfig
